package com.eu.habbo.habbohotel.crafting;

import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.users.Habbo;
import gnu.trove.map.hash.THashMap;
import gnu.trove.set.hash.THashSet;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class CraftingAltar
{
    private final Item baseItem;
    private final THashSet<Item> ingredients;
    private final THashMap<Integer, CraftingRecipe> recipes;

    public CraftingAltar(Item baseItem)
    {
        this.baseItem    = baseItem;

        this.ingredients = new THashSet<Item>();
        this.recipes     = new THashMap<Integer, CraftingRecipe>();
    }

    public void addIngredient(Item item)
    {
        this.ingredients.add(item);
    }

    public boolean hasIngredient(Item item)
    {
        return this.ingredients.contains(item);
    }

    public Map<CraftingRecipe, Boolean> matchRecipes(Map<Item, Integer> amountMap)
    {
        THashMap<CraftingRecipe, Boolean> foundRecepies = new THashMap<CraftingRecipe, Boolean>();

        for (Map.Entry<Integer, CraftingRecipe> set : this.recipes.entrySet())
        {
            boolean contains = true;
            boolean equals = true;

            if (set.getValue().isLimited() && !set.getValue().canBeCrafted())
            {
                continue;
            }

            for (Map.Entry<Item, Integer> entry : set.getValue().getIngredients().entrySet())
            {
                if (contains)
                {
                    if (!amountMap.containsKey(entry.getKey()))
                    {
                        contains = false;
                        equals = false;
                        break;
                    }
                    else
                    {
                        if (equals)
                        {
                            if (!entry.getValue().equals(amountMap.get(entry.getKey())))
                            {
                                if (entry.getValue() > amountMap.get(entry.getKey()))
                                {
                                    contains = true;
                                }
                                else
                                {
                                    contains = false;
                                }

                                equals = false;
                                break;
                            }
                        }
                    }
                }
            }

            if (contains)
            {
                foundRecepies.put(set.getValue(), equals);
            }
        }

        return foundRecepies;
    }


    public void addRecipe(CraftingRecipe recipe)
    {
        this.recipes.put(recipe.getId(), recipe);
    }

    public CraftingRecipe getRecipe(int id)
    {
        return this.recipes.get(id);
    }

    public CraftingRecipe getRecipe(String name)
    {
        for (Map.Entry<Integer, CraftingRecipe> set : this.recipes.entrySet())
        {
            if (set.getValue().getName().equals(name))
            {
                return set.getValue();
            }
        }

        return null;
    }

    public CraftingRecipe getRecipe(Map<Item, Integer> items)
    {
        for (Map.Entry<Integer, CraftingRecipe> set : this.recipes.entrySet())
        {
            CraftingRecipe recipe = set.getValue();

            for (Map.Entry<Item, Integer> entry : recipe.getIngredients().entrySet())
            {
                if (!(items.containsKey(entry.getKey()) && items.get(entry.getKey()).equals(entry.getValue())))
                {
                    recipe = null;
                    break;
                }
            }

            if (recipe != null)
            {
                return recipe;
            }
        }

        return null;
    }

    public List<CraftingRecipe> getRecipesForHabbo(Habbo habbo)
    {
        List<CraftingRecipe> recipeList = new ArrayList<CraftingRecipe>();

        for (Map.Entry<Integer, CraftingRecipe> set : this.recipes.entrySet())
        {
            if (!set.getValue().isSecret() || habbo.getHabboStats().hasRecipe(set.getValue().getId()))
            {
                recipeList.add(set.getValue());
            }
        }

        return recipeList;
    }

    public Item getBaseItem()
    {
        return this.baseItem;
    }

    public Collection<Item> getIngredients()
    {
        return this.ingredients;
    }

    public Collection<CraftingRecipe> getRecipes()
    {
        return this.recipes.values();
    }
}