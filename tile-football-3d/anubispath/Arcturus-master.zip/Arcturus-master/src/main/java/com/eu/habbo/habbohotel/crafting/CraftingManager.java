package com.eu.habbo.habbohotel.crafting;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.items.Item;
import gnu.trove.map.hash.THashMap;
import gnu.trove.procedure.TObjectProcedure;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public class CraftingManager
{
    /*
        crafting_altars_recipes
        crafting_recipes
        crafting_recipes_ingredients
     */
    private final THashMap<Item, CraftingAltar> altars;

    public CraftingManager()
    {
        this.altars = new THashMap<Item, CraftingAltar>();

        this.reload();
    }

    public void reload()
    {
        this.dispose();

        synchronized (this.altars)
        {

            try
            {
                PreparedStatement statement = Emulator.getDatabase().prepare("SELECT * FROM crafting_altars_recipes " +
                        "INNER JOIN crafting_recipes ON crafting_altars_recipes.recipe_id = crafting_recipes.id " +
                        "INNER JOIN crafting_recipes_ingredients ON crafting_recipes.id = crafting_recipes_ingredients.recipe_id " +
                        "WHERE crafting_recipes.enabled = ? ORDER BY altar_id ASC");

                statement.setString(1, "1");
                ResultSet set = statement.executeQuery();

                while (set.next())
                {
                    Item item = Emulator.getGameEnvironment().getItemManager().getItem(set.getInt("altar_id"));

                    if (item != null)
                    {
                        if (!this.altars.containsKey(item))
                        {
                            this.altars.put(item, new CraftingAltar(item));
                        }

                        CraftingAltar altar = this.altars.get(item);

                        if (altar != null)
                        {
                            CraftingRecipe recipe = altar.getRecipe(set.getInt("crafting_recipes_ingredients.recipe_id"));

                            if (recipe == null)
                            {
                                recipe = new CraftingRecipe(set);
                                altar.addRecipe(recipe);
                            }

                            Item ingredientItem = Emulator.getGameEnvironment().getItemManager().getItem(set.getInt("crafting_recipes_ingredients.item_id"));

                            if (ingredientItem != null)
                            {
                                recipe.addIngredient(ingredientItem, set.getInt("crafting_recipes_ingredients.amount"));
                                altar.addIngredient(ingredientItem);
                            }
                            else
                            {
                                Emulator.getLogging().logErrorLine("Unknown ingredient item " + set.getInt("crafting_recipes_ingredients.item_id"));
                            }
                        }
                    }
                }
            }
            catch (SQLException e)
            {
                Emulator.getLogging().logSQLException(e);
            }
        }
    }

    public int getRecipesWithItemCount(final Item item)
    {
        final int[] i = {0};

        synchronized (this.altars)
        {
            this.altars.forEachValue(new TObjectProcedure<CraftingAltar>()
            {
                @Override
                public boolean execute(CraftingAltar altar)
                {
                    if (altar.hasIngredient(item))
                    {
                        i[0]++;
                    }

                    return true;
                }
            });
        }

        return i[0];
    }

    public CraftingRecipe getRecipe(String recipeName)
    {
        synchronized (this.altars)
        {
            CraftingRecipe recipe = null;
            for (CraftingAltar altar : this.altars.values())
            {
                recipe = altar.getRecipe(recipeName);

                if (recipe != null)
                {
                    return recipe;
                }
            }
        }

        return null;
    }

    public CraftingAltar getAltar(Item item)
    {
        synchronized (this.altars)
        {
            return this.altars.get(item);
        }
    }

    public void dispose()
    {
        try
        {
            PreparedStatement statement = Emulator.getDatabase().prepare("UPDATE crafting_recipes SET remaining = ? WHERE id = ? LIMIT 1");
            for (CraftingAltar altar : this.altars.values())
            {
                for (CraftingRecipe recipe : altar.getRecipes())
                {
                    if (recipe.isLimited())
                    {
                        statement.setInt(1, recipe.getRemaining());
                        statement.setInt(2, recipe.getId());
                    }
                }
            }
        }
        catch (SQLException e)
        {
            Emulator.getLogging().logSQLException(e);
        }

        this.altars.clear();
    }
}