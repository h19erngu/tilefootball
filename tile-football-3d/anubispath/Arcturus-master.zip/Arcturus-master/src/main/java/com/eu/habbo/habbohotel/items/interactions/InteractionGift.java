package com.eu.habbo.habbohotel.items.interactions;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomUnit;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.ServerMessage;
import gnu.trove.set.hash.THashSet;

import java.sql.ResultSet;
import java.sql.SQLException;

public class InteractionGift extends HabboItem
{
    private int[] itemId;
    private int colorId;
    private int ribbonId;
    private boolean showSender;
    private String message;
    private String sender;
    private String look;

    public THashSet<HabboItem> items = new THashSet<HabboItem>();

    public boolean explode = false;

    public InteractionGift(ResultSet set, Item baseItem) throws SQLException
    {
        super(set, baseItem);

        this.loadData();
    }

    public InteractionGift(int id, int userId, Item item, String extradata, int limitedStack, int limitedSells)
    {
        super(id, userId, item, extradata, limitedStack, limitedSells);

        this.loadData();
    }

    @Override
    public void serializeExtradata(ServerMessage serverMessage)
    {
        //serverMessage.appendInt32(this.colorId * 1000 + this.ribbonId);
        serverMessage.appendInt32(1);
        serverMessage.appendInt32(6);
        serverMessage.appendString("EXTRA_PARAM");
        serverMessage.appendString("");
        serverMessage.appendString("MESSAGE");
        serverMessage.appendString(this.message);
        serverMessage.appendString("PURCHASER_NAME");
        serverMessage.appendString(this.showSender ? this.sender : "");
        serverMessage.appendString("PURCHASER_FIGURE");
        serverMessage.appendString(this.showSender ? this.look : "");
        serverMessage.appendString("PRODUCT_CODE");
        serverMessage.appendString(""); //this.gift.getItemId()
        serverMessage.appendString("state");
        serverMessage.appendString(this.explode ? "1" : "0");

        super.serializeExtradata(serverMessage);
    }

    @Override
    public void onClick(GameClient client, Room room, Object[] objects) throws Exception
    {

    }

    @Override
    public boolean canWalkOn(RoomUnit roomUnit, Room room, Object[] objects)
    {
        return false;
    }

    @Override
    public boolean isWalkable()
    {
        return false;
    }

    @Override
    public void onWalk(RoomUnit roomUnit, Room room, Object[] objects) throws Exception
    {

    }

    private void loadData()
    {
        String[] data = null;

        if (this.getExtradata().contains("\t"))
            data = this.getExtradata().split("\t");

        if (data != null && data.length >= 5)
        {
            int count = Integer.valueOf(data[0]);

            this.itemId = new int[count];

            for (int i = 0; i < count; i++)
            {
                this.itemId[i] = Integer.valueOf(data[i + 1]);
            }

            this.colorId = Integer.valueOf(data[count + 1]);
            this.ribbonId = Integer.valueOf(data[count + 2]);
            this.showSender = data[count + 3].equalsIgnoreCase("1");
            this.message = data[count + 4];

            if (data.length - count >= 7 && this.showSender)
            {
                this.sender = data[count + 5];
                this.look = data[count + 6];
            }
        } else
        {
            this.itemId = new int[0];
            this.colorId = 0;
            this.ribbonId = 0;
            this.showSender = false;
            this.message = "Please delete this present. Thanks!";
        }

        this.items.clear();
        for (int anItemId : itemId)
        {
            if (anItemId == 0)
                continue;

            this.items.add(Emulator.getGameEnvironment().getItemManager().loadHabboItem(anItemId));
        }
    }

    public int getColorId()
    {
        return colorId;
    }

    public int getRibbonId()
    {
        return ribbonId;
    }
}
